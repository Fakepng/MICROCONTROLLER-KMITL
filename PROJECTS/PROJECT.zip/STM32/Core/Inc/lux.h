/*
 * lux.h
 *
 *  Created on: Sep 25, 2024
 *      Author: Krit0
 */

#ifndef INC_LUX_H_
#define INC_LUX_H_

int to_lux(int raw);
double f(int x);

#endif /* INC_LUX_H_ */
